import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1])
raw=(root/'misura-aperture-CALSPEC-v2.py').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='f020e6fe2838acd11dcc004322be48caa9349d448e56883d0dd7662a556e8181'
code=raw.decode()
before="""            aperture=radius2<=rad**2
            support=good&((flags==0)|(flags==64))
            if not np.all(support[aperture]):
                r['apertures'][str(rad)]=dict(state='EXCLUDED_DQ_OR_SUPPORT')
                continue
            strict=aperture&(flags==0)
            rate=float(np.sum(sample[aperture]-bg)/h['EXPTIME'])
            assert rate>0
            r['apertures'][str(rad)]=dict(state='MEASURED',rate=rate,
                rateWithoutDq64=float(np.sum(sample[strict]-bg)/h['EXPTIME']),
                noDq64Flagged=bool(np.all(flags[aperture]==0)))"""
after="""            weights={}
            for subdivision in (16,32):
                edge=np.zeros(sample.shape,dtype=np.int32)
                shifts=(np.arange(subdivision)+0.5)/subdivision-0.5
                cells=radius2<=(rad+2)**2
                xpart=xx[cells]-cx
                ypart=yy[cells]-cy
                count=np.zeros(xpart.shape,dtype=np.int32)
                for dy in shifts:
                    for dx in shifts:
                        count+=((xpart+dx)**2+(ypart+dy)**2<=rad**2)
                edge[cells]=count
                weights[subdivision]=edge/(subdivision*subdivision)
            w=weights[32]
            aperture=w>0
            area_error=float(abs(w.sum()-np.pi*rad**2))
            assert area_error<0.03,(rad,area_error)
            support=good&((flags==0)|(flags==64))
            if not np.all(support[aperture]):
                r['apertures'][str(rad)]=dict(state='EXCLUDED_DQ_OR_SUPPORT', flags=sorted(int(x) for x in set(flags[aperture&~support])))
                continue
            strict=aperture&(flags==0)
            rate=float(np.sum((sample[aperture]-bg)*w[aperture])/h['EXPTIME'])
            low=weights[16]
            assert np.all(support[low>0])
            low_rate=float(np.sum((sample[low>0]-bg)*low[low>0])/h['EXPTIME'])
            assert rate>0 and low_rate>0
            r['apertures'][str(rad)]=dict(state='MEASURED',rate=rate,rate16=low_rate,
                subdivisionChangePct=100*(rate/low_rate-1), sampledArea=float(w.sum()),
                rateWithoutDq64=float(np.sum((sample[strict]-bg)*w[strict])/h['EXPTIME']),
                noDq64Flagged=bool(np.all(flags[aperture]==0)))"""
assert code.count(before)==1
code=code.replace(before,after).replace('BKL046_ACS_INDEPENDENT_APERTURE_PHOTOMETRY_V1','BKL046_ACS_FRACTIONAL_APERTURE_SENSITIVITY_V1')
code=code.replace("radiusUnits='detector pixels',","radiusUnits='detector pixels', edgeWeightSubdivisions=[16,32],")
exec(compile(code,'frozen-derived-fractional-aperture','exec'),{'__name__':'__main__'})
