import hashlib
import json
import statistics
import sys
from pathlib import Path

root = Path(sys.argv[1])
destination = Path(sys.argv[2])
parent_pin = 'f020e6fe2838acd11dcc004322be48caa9349d448e56883d0dd7662a556e8181'
parent = (root / 'misura-aperture-CALSPEC-v2.py').read_bytes()
assert hashlib.sha256(parent).hexdigest() == parent_pin
for c in (1,2):
    assert (root / f'wfc{c}_newpam.fits').is_file()

code = parent.decode()
start = code.index('        for rad in radii:')
end = code.index('\nvisits=defaultdict(list)', start)
body = """        r['variants']={}
        support=good&((flags==0)|(flags==64))
        shifts=(np.arange(32)+0.5)/32-0.5
        cells=(xx*xx+yy*yy)<=9**2
        values=sample[cells]-bg
        for width in (3,5,7):
            a=width//2
            patch=img[y-a:y+a+1,x-a:x+a+1]
            pf=dq[y-a:y+a+1,x-a:x+a+1]
            if not np.all(np.isfinite(patch)&(pf==0)):
                r['variants'][str(width)]=dict(state='EXCLUDED_CENTROID_DQ')
                continue
            ww=np.maximum(patch-np.median(patch),0)
            assert ww.sum()>0
            vy,vx=np.sum((np.indices(patch.shape)-a)*ww,axis=(1,2))/ww.sum()
            frac={}
            xp=xx[cells]-vx
            yp=yy[cells]-vy
            dx2=(xp[:,None]+shifts[None,:])**2
            dy2=(yp[:,None]+shifts[None,:])**2
            for rad in (3,5):
                w=np.count_nonzero(dx2[:,:,None]+dy2[:,None,:]<=rad**2,axis=(1,2))/1024
                assert abs(w.sum()-np.pi*rad**2)<0.03
                used=w>0
                frac[str(rad)]=float(np.sum(values[used]*w[used])/h['EXPTIME']) if np.all(support[cells][used]) else None
            r['variants'][str(width)]=dict(state='EVALUATED',deltaPixels=[float(vx-cx),float(vy-cy)],rates=frac)
"""
scope={'__name__':'__main__'}
exec(compile(code[:start]+body, 'pinned-acs-centroid-windows', 'exec'),scope)
visits=('j8jq03','j8jq06')
bands=('F606W','F658N','F660N')
rows=[r for r in scope['rows'] if r['visit'] in visits]
assert len(rows)==12
baseline_pin='9d2910cdfc91af3fc912e34410df7b874e36895ed7794a76321c314f073880d8'
baseline=(root/'sensibilita-apertura-frazionaria-v1.json').read_bytes()
assert hashlib.sha256(baseline).hexdigest()==baseline_pin
ref={r['obs']:r for r in json.loads(baseline)['rows']}
for row in rows:
    for rad in ('3','5'):
        base=row['variants']['5']['rates'][rad]
        assert abs(base/ref[row['obs']]['apertures'][rad]['rate']-1)<1e-13

results=[]
for width in ('3','5','7'):
    variants=[row['variants'][width] for row in rows]
    valid=[v for v in variants if v['state']=='EVALUATED']
    record=dict(width=int(width),centroids=len(valid),maxShiftAxisPixels=max(
        max(map(abs,v['deltaPixels'])) for v in valid),results={})
    for rad in ('3','5'):
        f={}
        for visit in visits:
            for band in bands:
                f[visit,band]=[row['variants'][width]['rates'][rad] for row in rows
                  if row['visit']==visit and row['band']==band and row['variants'][width]['state']=='EVALUATED'
                  and row['variants'][width]['rates'][rad] is not None]
        ratios={}
        for n,d in (('F658N','F606W'),('F658N','F660N'),('F660N','F606W')):
            if all(len(f[v,b])==2 for v in visits for b in (n,d)):
                a,z=visits
                ratios[f'{n}/{d}']=100*((statistics.mean(f[z,n])/statistics.mean(f[z,d]))/
                                       (statistics.mean(f[a,n])/statistics.mean(f[a,d]))-1)
        record['results'][rad]=ratios
    results.append(record)
report=dict(schema='BKL046_ACS_CENTROID_WINDOW_SENSITIVITY_V1',sourceSha256=parent_pin,
            baselineSha256=baseline_pin,scope='Estimator sensitivity under observed centroids, fixed sky and PAM',
            exposures=rows,summary=results,qualifiedControls=0,scientificClosures=0)
data=json.dumps(report,indent=2).encode()
if destination.exists():
    assert destination.read_bytes()==data
else:
    with destination.open('xb') as handle:
        handle.write(data)
print(json.dumps(results))
