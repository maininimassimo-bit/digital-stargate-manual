import hashlib
import json
import statistics
import sys
from pathlib import Path

root = Path(sys.argv[1])
out = Path(sys.argv[2])
parent = (root / 'misura-aperture-CALSPEC-v2.py').read_bytes()
pin = 'f020e6fe2838acd11dcc004322be48caa9349d448e56883d0dd7662a556e8181'
if hashlib.sha256(parent).hexdigest() != pin:
    raise ValueError('Source script hash mismatch')
for chip in (1, 2):
    if not (root / f'wfc{chip}_newpam.fits').is_file():
        raise FileNotFoundError('Offline analysis requires both pinned maps')

code = parent.decode()
start = code.index('        for rad in radii:')
end = code.index('\nvisits=defaultdict(list)', start)
body = """        r['offsets']={}
        offsets=(-0.5,-0.25,0.0,0.25,0.5)
        shifts=(np.arange(32)+0.5)/32-0.5
        support=good&((flags==0)|(flags==64))
        for rad in (3,5):
            cells=radius2<=(rad+2)**2
            xp=xx[cells]-cx
            yp=yy[cells]-cy
            values=sample[cells]-bg
            trusted=support[cells]
            measured=[]
            for dy in offsets:
                for dx in offsets:
                    d2x=(xp[:,None]+shifts[None,:]-dx)**2
                    d2y=(yp[:,None]+shifts[None,:]-dy)**2
                    w=np.count_nonzero(d2x[:,:,None]+d2y[:,None,:]<=rad**2,axis=(1,2))/1024
                    assert abs(w.sum()-np.pi*rad**2)<0.03
                    used=w>0
                    rate=float(np.sum(values[used]*w[used])/h['EXPTIME']) if np.all(trusted[used]) else None
                    assert rate is None or rate>0
                    measured.append(dict(dx=dx,dy=dy,rate=rate))
            r['offsets'][str(rad)]=measured
"""
scope = {'__name__': '__main__'}
exec(compile(code[:start] + body, 'pinned-acs-center-grid', 'exec'), scope)
rows = [row for row in scope['rows'] if row['visit'] in ('j8jq03', 'j8jq06')]
baseline = (root / 'sensibilita-apertura-frazionaria-v1.json').read_bytes()
baseline_pin = '9d2910cdfc91af3fc912e34410df7b874e36895ed7794a76321c314f073880d8'
assert hashlib.sha256(baseline).hexdigest() == baseline_pin
baseline_rows = {row['obs']: row for row in json.loads(baseline)['rows']}
assert len(rows) == 12
bands = ('F606W', 'F658N', 'F660N')
visits = ('j8jq03', 'j8jq06')
report = []
for rad in ('3', '5'):
    for row in rows:
        cells = row['offsets'][rad]
        assert len(cells) == 25
        assert cells[12]['dx'] == cells[12]['dy'] == 0.0
        expected = baseline_rows[row['obs']]['apertures'][rad]['rate']
        assert abs(cells[12]['rate'] / expected - 1) < 1e-13
    for cap in (0.25, 0.5):
        bounds = {}
        excluded = 0
        for visit in visits:
            for band in bands:
                opts = [[p for p in row['offsets'][rad] if max(abs(p['dx']), abs(p['dy'])) <= cap]
                        for row in rows if row['visit'] == visit and row['band'] == band]
                assert len(opts) == 2
                excluded += sum(p['rate'] is None for items in opts for p in items)
                rates = [[p['rate'] for p in items if p['rate'] is not None] for items in opts]
                bounds[visit, band] = (statistics.mean(min(r) for r in rates),
                                       statistics.mean(max(r) for r in rates))
        ratios = {}
        for n, d in (('F658N', 'F606W'), ('F658N', 'F660N'), ('F660N', 'F606W')):
            a, b = visits
            low = bounds[b, n][0] / bounds[b, d][1] / (bounds[a, n][1] / bounds[a, d][0])
            high = bounds[b, n][1] / bounds[b, d][0] / (bounds[a, n][0] / bounds[a, d][1])
            ratios[f'{n}/{d}'] = [100 * (low - 1), 100 * (high - 1)]
        report.append(dict(radiusPixels=int(rad), maxOffsetPerAxisPixels=cap, dqExcluded=excluded,
                           visitRatioDeltaBoundsPct=ratios))
result = dict(schema='BKL046_ACS_APERTURE_CENTER_SENSITIVITY_V1', sourceSha256=pin,
              baselineSha256=baseline_pin, gridOffsetsPixels=[-0.5,-0.25,0,0.25,0.5],
              scope='Independent center offsets per exposure, fixed sky and PAM, descriptive grid bounds',
              exposures=rows, bounds=report, qualifiedControls=0, scientificClosures=0)
data = json.dumps(result, indent=2).encode()
if out.exists():
    assert out.read_bytes() == data
else:
    with out.open('xb') as handle:
        handle.write(data)
print(json.dumps(report))
