<?php
$dir = ".";
$prefix = "meteors";
$title = "Meteore candidate - da verificare";
include_once("../show_thumbnails.php");
?>
