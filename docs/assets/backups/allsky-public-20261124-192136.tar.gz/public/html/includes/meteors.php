<?php

if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    include_once('functions.php');
    redirect("/index.php");
}

function ListMeteors($aDay = null)
{
	global $pageIcon, $pageHelp;
	echo '<p><a class="btn btn-default" external="true" href="/meteor-review.php">Revisione nuovi candidati temporali</a></p>';

	$day = $aDay === null ? (string) getVariableOrDefault($_REQUEST, 'day', '') : (string) $aDay;
	if ($day === "All") {
		ListFileType('meteors/', 'meteors', 'Meteors', 'picture');
		return;
	}
	if (!preg_match('/^\d{8}$/', $day)) {
		echo "<div class='panel panel-allsky'><div class='panel-heading'>Displaying meteors</div><div class='panel-body'>";
		echo "<div class='alert alert-danger'>ERROR: Invalid or missing 'day' parameter.</div></div></div>";
		return;
	}

	$dayDir = ALLSKY_IMAGES . "/$day";
	$meteorDirectory = "$dayDir/meteors";
	$thumbnailDirectory = "$dayDir/meteorsthumbnails";
	$deleteMessage = '';
	$deleteType = 'success';
	$deleteName = (string) getVariableOrDefault($_POST, 'delete_meteor', '');
	if ($deleteName !== '') {
		if (!CSRFValidate()) {
			$deleteMessage = 'Unable to delete meteor: invalid CSRF token.';
			$deleteType = 'danger';
		} else if (!preg_match('/^meteors-\d{14}\.(jpg|png)$/i', $deleteName)) {
			$deleteMessage = 'Unable to delete meteor: invalid file name.';
			$deleteType = 'danger';
		} else {
			$baseName = pathinfo($deleteName, PATHINFO_FILENAME);
			$extension = pathinfo($deleteName, PATHINFO_EXTENSION);
			$markedName = $baseName . '-marked.' . $extension;
			$filesToDelete = [
				$meteorDirectory . '/' . $deleteName,
				$thumbnailDirectory . '/' . $deleteName,
				$meteorDirectory . '/' . $markedName,
				$thumbnailDirectory . '/' . $markedName,
				$meteorDirectory . '/' . $baseName . '.json',
				ALLSKY_HOME . '/html/allsky/meteors/' . $deleteName,
				ALLSKY_HOME . '/html/allsky/meteors/thumbnails/' . $deleteName,
			];
			$existingFiles = array_filter($filesToDelete, 'is_file');
			if (count($existingFiles) === 0) {
				$deleteMessage = "Meteor $deleteName was not found in $meteorDirectory.";
				$deleteType = 'warning';
			} else {
				$command = 'sudo rm -f ' . implode(' ', array_map('escapeshellarg', $existingFiles));
				$output = [];
				$returnCode = 0;
				exec($command . ' 2>&1', $output, $returnCode);
				if ($returnCode === 0) {
					$deleteMessage = "Deleted meteor $deleteName.";
				} else {
					$deleteMessage = 'Unable to delete meteor: ' . implode(' ', $output);
					$deleteType = 'danger';
				}
			}
		}
	}

	$meteorFiles = [];
	if (is_dir($meteorDirectory)) {
		$files = scandir($meteorDirectory);
		if ($files !== false) {
			foreach ($files as $file) {
				if (preg_match('/^meteors-(\d{8})(\d{6})\.(jpg|png)$/i', $file, $matches)) {
					$meteorFiles[] = [
						'name' => $file,
						'date' => $matches[1],
						'time' => $matches[2],
					];
				}
			}
		}
	}

	usort($meteorFiles, function ($left, $right) {
		return strcmp($left['name'], $right['name']);
	});

	$hasMarkedMeteors = false;
	$hasMeteorMetadata = false;
	foreach ($meteorFiles as $meteor) {
		$baseName = pathinfo($meteor['name'], PATHINFO_FILENAME);
		if (is_file($meteorDirectory . '/' . $baseName . '-marked.' . pathinfo($meteor['name'], PATHINFO_EXTENSION))) {
			$hasMarkedMeteors = true;
		}
		if (is_file($meteorDirectory . '/' . $baseName . '.json') || is_file($meteorDirectory . '/' . $day . $meteor['time'] . '.json')) {
			$hasMeteorMetadata = true;
		}
	}

	$dateObject = DateTimeImmutable::createFromFormat('!Ymd', $day);
	$displayDate = $dateObject !== false ? $dateObject->format('d-M-Y') : $day;
	$title = "Meteors for $displayDate";

	echo "<div class='panel panel-allsky'>";
	echo "<div class='panel-heading clearfix'>";
	echo "<span><i class='" . htmlspecialchars($pageIcon, ENT_QUOTES) . "'></i> " . htmlspecialchars($title) . "</span>";
	if (!empty($pageHelp)) {
		echo "<a class='pull-right' href='" . htmlspecialchars($pageHelp, ENT_QUOTES) . "' target='_blank' rel='noopener noreferrer' data-toggle='tooltip' data-container='body' data-placement='left' title='Help'>";
		echo "<i class='fa-solid fa-circle-question'></i> Help</a>";
	}
	echo "</div><div class='panel-body'>";
	echo "<div class='functions-listfiletype-back'><a href='javascript:history.back()' class='btn btn-default'><i class='fa fa-arrow-left'></i> Back</a></div>";
	if ($deleteMessage !== '') {
		echo "<div class='alert alert-" . htmlspecialchars($deleteType, ENT_QUOTES) . "'>" . htmlspecialchars($deleteMessage, ENT_QUOTES) . "</div>";
	}

	if (count($meteorFiles) === 0) {
		echo "<div class='as-wifi-placeholder as-wifi-placeholder-error functions-listfiletype-error'>";
		echo "<div class='as-wifi-placeholder-icon'><i class='fa fa-triangle-exclamation'></i></div>";
		echo "<div class='as-wifi-placeholder-title'>No meteors found</div>";
		echo "<div class='as-wifi-placeholder-text'>There are no meteor images for " . htmlspecialchars($day, ENT_QUOTES) . ".</div></div>";
		echo "</div></div>";
		return;
	}

	if (! $hasMarkedMeteors && ! $hasMeteorMetadata) {
		ListFileType('meteors/', 'meteors', 'Meteors', 'picture');
		return;
	}

	$thumbnailWidth = "200px";
	echo "<style>.meteors-table th, .meteors-table td, .meteors-table td form { vertical-align: middle; }.meteors-table td { vertical-align: middle !important; }.meteors-table img { max-width: {$thumbnailWidth}; height: auto; }</style>";
	echo "<div class='table-responsive'><table class='table table-striped table-hover meteors-table'><thead><tr>";
	echo "<th style='text-align: center'>Meteor(s)</th>";
	echo "<th style='text-align: center'>Marked</th>";
	echo "<th>Meteor Data</th>";
	echo "<th style='text-align: center'>Metadata</th>";
	echo "<th style='text-align: center'>Delete</th>";
	echo "</tr></thead><tbody>";
	foreach ($meteorFiles as $meteor) {
		$name = $meteor['name'];
		$baseName = pathinfo($name, PATHINFO_FILENAME);
		$extension = pathinfo($name, PATHINFO_EXTENSION);
		$markedName = $baseName . '-marked.' . $extension;
		$imageUrl = '/images/' . rawurlencode($day) . '/meteors/' . rawurlencode($name);
		$thumbnailUrl = '/images/' . rawurlencode($day) . '/meteorsthumbnails/' . rawurlencode($name);
		$markedImagePath = $meteorDirectory . '/' . $markedName;
		$markedExists = is_file($markedImagePath);
		$markedImageUrl = '/images/' . rawurlencode($day) . '/meteors/' . rawurlencode($markedName);
		$markedThumbnailUrl = '/images/' . rawurlencode($day) . '/meteorsthumbnails/' . rawurlencode($markedName);
		$lightboxSize = getLightboxSizeAttribute($meteorDirectory . '/' . $name);
		$metadata = [];
		$metadataFilePath = null;
		$metadataPaths = [
			$meteorDirectory . '/' . $baseName . '.json',
			$meteorDirectory . '/' . $day . $meteor['time'] . '.json',
		];
		foreach ($metadataPaths as $metadataPath) {
			if (is_file($metadataPath)) {
				$metadataFilePath = $metadataPath;
				$metadataContents = file_get_contents($metadataPath);
				if ($metadataContents !== false) {
					$metadataContents = preg_replace('/^\xEF\xBB\xBF/', '', $metadataContents);
					$decodedMetadata = json_decode($metadataContents, true);
					if (is_array($decodedMetadata)) {
						$metadata = array_values(array_filter($decodedMetadata, 'is_array'));
						break;
					}
				}
			}
		}

		$rowCount = max(1, count($metadata));
		echo '<tr>';
		$imgDate = htmlspecialchars($meteor['date'], ENT_QUOTES);
		$imgTime = htmlspecialchars(substr($meteor['time'], 0, 2) . ':' . substr($meteor['time'], 2, 2) . ':' . substr($meteor['time'], 4, 2), ENT_QUOTES);
		echo '<td style="text-align: center">';
			echo '<a href="' . htmlspecialchars($imageUrl, ENT_QUOTES) . '" data-lg-size="' . htmlspecialchars($lightboxSize, ENT_QUOTES) . '">';
			echo '<img align="center" src="' . htmlspecialchars($thumbnailUrl, ENT_QUOTES) . '" alt="' . htmlspecialchars($name, ENT_QUOTES) . '" loading="lazy"></a>';
			echo '<br>' . $imgDate . '&nbsp; &nbsp;' . $imgTime;
		echo '</td>';

		echo '<td style="text-align: center">';
		if ($markedExists) {
			echo '<a href="' . htmlspecialchars($markedImageUrl, ENT_QUOTES) . '" data-lg-size="' . htmlspecialchars(getLightboxSizeAttribute($markedImagePath), ENT_QUOTES) . '">';
			echo '<img align="center" src="' . htmlspecialchars($markedThumbnailUrl, ENT_QUOTES) . '" alt="' . htmlspecialchars($markedName, ENT_QUOTES) . '" loading="lazy"></a>';
			echo '<br>&nbsp;';
		} else {
			echo '-';
		}
		echo '</td>';

		echo "<td>";
		for ($metadataIndex = 0; $metadataIndex < $rowCount; $metadataIndex++) {
			$metadataItem = $metadata[$metadataIndex] ?? [];

			$length = htmlspecialchars((string)($metadataItem['length'] ?? '-'), ENT_QUOTES);
			$angle = htmlspecialchars((string)($metadataItem['angle'] ?? '-'), ENT_QUOTES);
			$peak = htmlspecialchars((string)($metadataItem['peak'] ?? '-'), ENT_QUOTES);
			$p1Parts = is_array($metadataItem['p1'] ?? null) ? array_map('strval', $metadataItem['p1']) : [];
			$p2Parts = is_array($metadataItem['p2'] ?? null) ? array_map('strval', $metadataItem['p2']) : [];
			$p1 = count($p1Parts) >= 2 ? $p1Parts[0] . ', ' . $p1Parts[1] : '-';
			$p2 = count($p2Parts) >= 2 ? $p2Parts[0] . ', ' . $p2Parts[1] : '-';

			if ($metadataIndex > 0) {
				echo '<hr width="75%" style="border-color: #aaa;">';		// make it obvious this is for a different meteor
			}
			if ($length !== "-" || $angle !== "-" || $peak !== "-" || $p1 !== "-" || $p2 !== "-") {
				echo "Length = $length<br>Angle = $angle<br>Peak = $peak<br><br>P1 = (" . htmlspecialchars($p1, ENT_QUOTES) . ")<br>P2 = (" . htmlspecialchars($p2, ENT_QUOTES) . ")";
			} else {
				echo "-";
			}
		}
		echo "</td>";

		echo '<td style="text-align: center">';
		if ($metadataFilePath !== null) {
			$jsonUrl = '/images/' . rawurlencode($day) . '/meteors/' . rawurlencode(basename($metadataFilePath));
			echo '<a href="' . htmlspecialchars($jsonUrl, ENT_QUOTES) . '" target="_blank" rel="noopener noreferrer" onclick="return openMeteorMetadata(this.href);" title="View meteor Metadata" aria-label="View meteor Metadata"><i class="fa fa-2x fa-file-code"></i></a>';
		} else {
			echo '-';
		}
		echo '</td>';

		echo '<td style="text-align: center">';
			echo '<form method="post" action="index.php?page=list_meteors&amp;day=' . rawurlencode($day) . '" onsubmit="return confirm(\'Delete this meteor and its related files?\');">';
			echo '<input type="hidden" name="delete_meteor" value="' . htmlspecialchars($name, ENT_QUOTES) . '">';
			CSRFToken();
			echo '<button type="submit" class="btn btn-danger btn-sm" title="Delete meteor"><i class="fa fa-trash"></i></button></form>';
		echo '</td>';
		echo '</tr>';
	}
	echo '</tbody></table></div></div></div>';

	echo addAsset([
		'/js/lightgallery/css/lightgallery-bundle.min.css',
		'/js/lightgallery/css/lg-transitions.css',
		'/js/lightgallery/lightgallery.min.js',
		'/js/lightgallery/plugins/zoom/lg-zoom.min.js',
		'/js/lightgallery/plugins/thumbnail/lg-thumbnail.min.js'
	]);
?>
<script>
function openMeteorMetadata(url) {
	const width = 800;
	const height = 600;
	const left = Math.max(0, Math.round((window.screenX || window.screenLeft || 0) + ((window.outerWidth || window.innerWidth) - width) / 2));
	const top = Math.max(0, Math.round((window.screenY || window.screenTop || 0) + ((window.outerHeight || window.innerHeight) - height) / 2));
	const features = `popup=yes,width=${width},height=${height},left=${left},top=${top},scrollbars=yes,resizable=yes`;
	const popup = window.open(url, 'meteor-json', features);
	if (!popup) {
		return true;
	}

	try {
		popup.moveTo(left, top);
		popup.resizeTo(width, height);
		popup.focus();
	} catch (error) {
		// Browsers may restrict moving or resizing windows.
	}
	return false;
}

$(document).ready(function () {
  const galleryElement = document.querySelector('.table tbody');
  if (!galleryElement) {
    return;
  }

  lightGallery(galleryElement, {
    selector: 'a[data-lg-size]',
    plugins: [lgZoom, lgThumbnail],
    mode: 'lg-slide-circular',
    speed: 0,
    download: false,
    thumbnail: true
  });
});
</script>
<?php
}

?>
