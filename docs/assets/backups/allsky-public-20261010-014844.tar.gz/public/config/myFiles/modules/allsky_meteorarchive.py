"""Digital Stargate: native meteor detection with candidate image archiving.

Installed in config/myFiles/modules; upstream Allsky modules remain unchanged.
"""
import copy
import json
import os
import re
from datetime import datetime
from pathlib import Path

import cv2
import allsky_shared as shared
from allsky_meteor import ALLSKYMETEOR


def write_image(path, image):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name('.' + path.stem + '.tmp.jpg')
    if not cv2.imwrite(str(temporary), image, [cv2.IMWRITE_JPEG_QUALITY, 95]):
        raise OSError('Unable to write meteor image: ' + str(path))
    os.replace(temporary, path)


def archive_candidate(image, detections, timestamp, night_directory, public_directory):
    if not detections:
        return None
    if not re.fullmatch(r'\d{14}', timestamp):
        raise ValueError('Invalid meteor timestamp')
    datetime.strptime(timestamp, '%Y%m%d%H%M%S')
    name = 'meteors-' + timestamp
    night = Path(night_directory)
    public = Path(public_directory)
    original = night / 'meteors' / (name + '.jpg')
    marked = shared.draw_detections(image, detections)
    width = min(320, image.shape[1])
    size = (width, max(1, round(image.shape[0] * width / image.shape[1])))
    # Original data stays unannotated; the marked copy is for human review.
    write_image(original, image)
    write_image(night / 'meteors' / (name + '-marked.jpg'), marked)
    write_image(night / 'meteorsthumbnails' / (name + '.jpg'), cv2.resize(image, size))
    write_image(night / 'meteorsthumbnails' / (name + '-marked.jpg'), cv2.resize(marked, size))
    metadata = [dict(candidate=True, confirmed=False, detector='Allsky meteor v1.0.0',
                     length=d['length_px'], angle=d['angle_deg'], score=d['score'],
                     bbox=list(d['bbox']), center=list(d['center']), aspect=d['aspect'])
                for d in detections]
    metadata_file = night / 'meteors' / (name + '.json')
    temporary = metadata_file.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
    os.replace(temporary, metadata_file)
    # Independent public copies survive the normal raw-image retention window.
    write_image(public / 'thumbnails' / (name + '.jpg'), cv2.resize(image, size))
    write_image(public / (name + '.jpg'), image)
    return original


class ALLSKYMETEORARCHIVE(ALLSKYMETEOR):
    meta_data = copy.deepcopy(ALLSKYMETEOR.meta_data)
    meta_data.update(name='Meteor Detection + Automatic Archive',
                     description='Detect candidate streaks and save original, marked image and metadata.',
                     module='allsky_meteorarchive', version='v1.0.0-digitalstargate')

    def run(self):
        # Guard against accidental addition to a daytime or periodic flow.
        if getattr(shared, 'TOD', '') != 'night':
            return 'Meteor archive: skipped outside night capture'
        image = shared.image
        mask = self.get_param('mask', '', str)
        detection_image = shared.mask_image(image, mask) if mask else image
        detections = shared.detect_meteors(detection_image,
                                           min_len_px=self.get_param('minlength', 100, int))
        if mask:
            # Reject contours touching excluded obstacles or artificial mask edges.
            mask_image = cv2.imread(str(Path(shared.ALLSKY_OVERLAY) / 'images' / mask), 0)
            safe = cv2.erode((mask_image > 250).astype('uint8'), cv2.getStructuringElement(cv2.MORPH_RECT, (31,31)))
            detections = [d for d in detections if safe[d['bbox'][1]:d['bbox'][1]+d['bbox'][3],
                                                       d['bbox'][0]:d['bbox'][0]+d['bbox'][2]].size and
                          safe[d['bbox'][1]:d['bbox'][1]+d['bbox'][3],
                               d['bbox'][0]:d['bbox'][0]+d['bbox'][2]].all()]
        data = {'AS_METEORCOUNT': len(detections), 'AS_METEORIMAGE': '',
                'AS_METEORIMAGEPATH': '', 'AS_METEORIMAGEURL': ''}
        if detections and not self.get_param('ALLSKYTESTMODE', False, bool):
            frame = Path(shared.CURRENTIMAGEPATH)
            match = re.search(r'(\d{14})', frame.name)
            timestamp = match.group(1) if match else datetime.fromtimestamp(frame.stat().st_mtime).strftime('%Y%m%d%H%M%S')
            public = Path(os.environ['ALLSKY_HOME']) / 'html' / 'allsky' / 'meteors'
            try:
                saved = archive_candidate(image, detections, timestamp, shared.imageFolder, public)
                data.update(AS_METEORIMAGE=saved.name, AS_METEORIMAGEPATH=str(saved),
                            AS_METEORIMAGEURL='/images/' + Path(shared.imageFolder).name + '/meteorsthumbnails/' + saved.name)
            except Exception as error:
                self.log(0, 'ERROR: Meteor candidate archive failed: ' + str(error))
                raise
        if not self.get_param('ALLSKYTESTMODE', False, bool):
            shared.saveExtraData(self.meta_data['extradatafilename'], data,
                                 self.meta_data['module'], self.meta_data['extradata'], event=self.event)
        return str(len(detections)) + ' meteor candidates; archive enabled'


def meteorarchive(params, event):
    return ALLSKYMETEORARCHIVE(params, event).run()
