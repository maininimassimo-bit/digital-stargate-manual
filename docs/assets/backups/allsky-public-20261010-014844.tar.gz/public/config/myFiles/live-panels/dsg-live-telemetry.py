import json, time, math, re, urllib.request
from pathlib import Path
from datetime import datetime, timezone

HOME = Path('/home/pi/allsky')
EXTRA = HOME / 'tmp/extra'
OUTPUT = HOME / 'html/allsky/dsg-live-data.json'
RELAY = 'https://__PRIVATE_RELAY_HOST__/v1/observatory-status'

def load(path):
    try: return json.loads(path.read_text())
    except (OSError, ValueError): return {}

def values(name, age):
    p = EXTRA / name
    if not p.exists() or time.time() - p.stat().st_mtime > age: return {}
    return {k: v.get('value') for k,v in load(p).items() if isinstance(v, dict)}

def get(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'DigitalStargate-Allsky/1.0'})
    with urllib.request.urlopen(req, timeout=8) as response:
        return json.loads(response.read(2000000))

def timestamp(value):
    value = re.sub(r'(\.\d{6})\d+(?=Z|[+-])', r'\1', value)
    return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()

def collect():
    now = time.time()
    camera = values('allsky_camera.json', 180)
    pi = values('allsky_pistatus.json', 180)
    solar = values('allsky_solarsystem.json', 600)
    stars = values('allsky_starcount.json', 180)
    result = {'generated_at': now, 'camera': {}, 'pi': {}, 'weather': None,
              'stars': None, 'meteors': None, 'iss': None, 'aircraft': None, 'astronomy': None}
    try:
        sun=float(solar['AS_SUN_ELEVATION']); moon=float(solar['AS_MOON_ELEVATION'])
        from astral import Observer
        from astral.sun import sunrise
        from datetime import timedelta
        from zoneinfo import ZoneInfo
        settings=load(HOME/'config/settings.json')
        def coord(s):
            n=float(re.search(r'-?\d+(?:\.\d+)?',str(s)).group())
            return -abs(n) if str(s).upper().endswith(('S','W')) else n
        observer=Observer(coord(settings['latitude']),coord(settings['longitude']),100)
        tz=ZoneInfo('Europe/Rome');day=datetime.now(tz).date()
        rise=sunrise(observer,day,tzinfo=tz).timestamp()
        if rise <= now: rise=sunrise(observer,day+timedelta(days=1),tzinfo=tz).timestamp()
        phase=('Giorno' if sun>=0 else 'Crepuscolo civile' if sun>=-6 else
               'Crepuscolo nautico' if sun>=-12 else 'Crepuscolo astronomico' if sun>=-18 else 'Notte astronomica')
        result['astronomy']={'sun_elevation':sun,'moon_elevation':moon,'phase':phase,'next_sunrise':rise}
    except (KeyError,ValueError,TypeError,ImportError,AttributeError): pass
    for k in ['AS_CAMERAIMAGE','AS_DAY_OR_NIGHT','AS_EXPOSURE_S','AS_GAIN','AS_TEMPERATURE_C']:
        result['camera'][k] = camera.get(k)
    result['camera']['moon'] = solar.get('AS_MOON_ILLUMINATION')
    for k in ['AS_CPUTEMP_C','AS_MEMORYUSEDPERCENTAGE','AS_DISKFREE','AS_UPTIME']:
        result['pi'][k] = pi.get(k)
    if camera.get('AS_DAY_OR_NIGHT') == 'NIGHT':
        result['stars'] = stars.get('AS_STARCOUNT') if stars.get('AS_STARIMAGE') == camera.get('AS_CAMERAIMAGE') else None
        folder = str(camera.get('AS_DATE_NAME') or load(EXTRA/'allsky_camera.json').get('AS_DATE_NAME',{}).get('value',''))
        if re.fullmatch(r'\d{8}', folder):
            files = list((HOME/'images'/folder/'meteors').glob('meteors-*.json'))
            result['meteors'] = {'frames': len(files), 'traces': sum(len(load(p)) for p in files), 'night':folder}
    try:
        raw = get(RELAY); w = raw.get('systems',{}).get('weather',{})
        if w.get('quality') == 'CURRENT' and timestamp(w['observed_at_utc']) <= now + 30 and timestamp(w['fresh_until_utc']) > now:
            result['weather'] = {k:w.get(k) for k in ['temperature_c','humidity_pct','dew_point_c','observed_at_utc','fresh_until_utc']}
    except Exception: pass
    passes=[]
    for k,v in solar.items():
        if re.match(r'AS_.*25544_PASS\d+_RISE_TIME$',k):
            try:
                t=float(v)
                if t > now: passes.append(t)
            except (ValueError,TypeError): pass
    if passes: result['iss'] = min(passes)
    elif solar.get('AS_25544_VISIBLE_PASSES') == 'None Found': result['iss']='none'
    try:
        raw=get('https://opendata.adsb.fi/api/v3/lat/42.58/lon/11.52/dist/27')
        if raw.get('msg') == 'No error' and abs(float(raw.get('now',0))/1000-now) < 120:
            aircraft=[a for a in raw.get('ac',[]) if a.get('alt_baro') != 'ground' and float(a.get('seen_pos',999)) <= 60]
            aircraft.sort(key=lambda a:float(a.get('dst',999)))
            result['aircraft']={'count':len(aircraft),'callsign':str(aircraft[0].get('flight','')).strip() if aircraft else '', 'radius_km':50}
    except Exception: pass
    temp=OUTPUT.with_suffix('.tmp')
    temp.write_text(json.dumps(result,ensure_ascii=False)+'\n')
    temp.replace(OUTPUT)
    print(json.dumps({'weather':bool(result['weather']),'stars':result['stars'],'meteors':result['meteors'],'iss':result['iss'],'aircraft':result['aircraft']}))

if __name__=='__main__': collect()
