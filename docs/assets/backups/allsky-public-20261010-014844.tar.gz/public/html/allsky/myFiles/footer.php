<footer class="dsg-portal-footer">
<a href="https://maininimassimo-bit.github.io/digital-stargate-manual/" target="_blank" rel="noopener noreferrer">
<span class="dsg-portal-name">Digital Stargate</span>
<span class="dsg-portal-tagline">Il tuo varco verso l’Universo</span>
<span class="dsg-portal-action">Esplora il portale &#8599;</span>
</a>
</footer>
