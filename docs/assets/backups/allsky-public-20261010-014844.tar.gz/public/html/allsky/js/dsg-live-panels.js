(() => {
  'use strict';
  const unavailable='Non disponibile';
  const put=(id,text)=>{const e=document.getElementById(id);if(e)e.textContent=text;};
  const num=(x,suffix='',dp=1)=>x!==null&&x!==undefined&&Number.isFinite(Number(x))?Number(x).toLocaleString('it-IT',{maximumFractionDigits:dp})+suffix:unavailable;
  const local=x=>new Date(x).toLocaleString('it-IT',{timeZone:'Europe/Rome'});
  function reset(){document.querySelectorAll('[data-dsg-value]').forEach(e=>e.textContent=unavailable);}
  async function update(){
    try{
      const r=await fetch('dsg-live-data.json?t='+Date.now(),{cache:'no-store'});
      if(!r.ok)throw Error('telemetry');const d=await r.json();
      if(Date.now()/1000-d.generated_at>150)throw Error('stale');
      const c=d.camera,p=d.pi,w=d.weather;
      const a=d.astronomy;
      put('dsg-sky-phase',a?a.phase:unavailable);
      put('dsg-sun-alt',a?num(a.sun_elevation,'°'):unavailable);
      put('dsg-moon-alt',a?(a.moon_elevation<0?'Sotto l’orizzonte · '+num(a.moon_elevation,'°'):num(a.moon_elevation,'°')):unavailable);
      put('dsg-next-sunrise',a?local(a.next_sunrise*1000):unavailable);
      const m=String(c.AS_CAMERAIMAGE||'').match(/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/);
      put('dsg-date',m?`${m[3]}/${m[2]}/${m[1]} ${m[4]}:${m[5]}:${m[6]}`:unavailable);
      put('dsg-exposure',num(c.AS_EXPOSURE_S,' s',3));
      put('dsg-gain',num(c.AS_GAIN,'',0));put('dsg-sensor',num(c.AS_TEMPERATURE_C,' °C'));put('dsg-moon',num(c.moon,' %'));
      const fresh=w&&Date.parse(w.fresh_until_utc)>Date.now();
      put('dsg-ambient',fresh?num(w.temperature_c,' °C'):unavailable);
      put('dsg-humidity',fresh?num(w.humidity_pct,' %'):unavailable);put('dsg-dew',fresh?num(w.dew_point_c,' °C'):unavailable);
      put('dsg-weather-time',fresh?local(w.observed_at_utc):'Dati non aggiornati');
      put('dsg-stars',c.AS_DAY_OR_NIGHT==='NIGHT'?num(d.stars,'',0):'Solo di notte');
      put('dsg-meteors',d.meteors?`${d.meteors.frames} fotogrammi · ${d.meteors.traces} tracce`:'Solo di notte');
      put('dsg-iss',typeof d.iss==='number'?local(d.iss*1000):d.iss==='none'?'Nessuno nei prossimi 5 giorni':unavailable);
      put('dsg-aircraft',d.aircraft?`${d.aircraft.count} entro 50 km${d.aircraft.callsign?' · '+d.aircraft.callsign:''}`:unavailable);
      put('dsg-cpu',num(p.AS_CPUTEMP_C,' °C'));put('dsg-ram',num(p.AS_MEMORYUSEDPERCENTAGE,' %'));
      put('dsg-disk',p.AS_DISKFREE==null?unavailable:num(Number(p.AS_DISKFREE)/1e9,' GB'));put('dsg-uptime',p.AS_UPTIME||unavailable);
    }catch(e){reset();}
  }
  document.addEventListener('DOMContentLoaded',()=>{update();setInterval(update,15000);});
})();
